'Set per torte <<COOKIN ITALY>>',350,200
'Crepiera profi-crepe G3FERRARI',450,170
'Macchina per caffe espresso single PLUS GUZZINI',550,150
'Friggitrice rotofry DE LONGHI',650,140
'Forno elettrico ventilato titanium 55G3FERRARI',800,100
'Piastra per capelli B9 100',350,200
'Custodia <<CLASSIC>> MOLESKINE',450,170
'Zaino BUSINESS MOLESKINE',550,150
'Collana NIKE Y SWAROVSSKI',650,140
'Trolley cabina MYCLOUD MOLESKINE',800,100
'Tovaglia rettangolare da 6 posti CALEFFI',350,200
'Completo letto matrimoniale <<TIGLIO>> LAURA BIAGIOTTI HOME',450,170
'Trapunta matrimoniale <<TIGLIO>> LAURA BIAGIOTTI HOME',550,150
'Carrello pieghevole BRANDANI',650,140
'Mini frigo COCA COLA',800,100
'Caricatore wireless DOUNT BASEUS',350,200
'Powerbank SAMSUNG',450,170
'Bottiglia termica SMART PURO',550,150
'Tablet 3G TREVI',650,140
'Set karaoke BRANDANI',800,100
'Borsa BIMBY',350,200
'BIMBY TOY',450,170
'COOK-KEY con 6 mesi di accesso a COOKIDOO',550,150
'Boccale BIMBY TM6',650,140
'Set accessori per BIMBY TM6',800,100