SNTJNR80T66I603N,Janira,Santucci,Bolzano(BZ),1980-12-26,janirasantucci1980@mail.it,Via Sciesa,25,84121
GTTRLN76C29L752P,Rosolino,Guetta,Bergamo(BG),1976-03-29,rosolinoguetta1976@mail.it,Via Imbriani,22,84123
MNZJLU58B52L004J,Julia,Manzi,Avellino(AV),1958-02-12,juliamanzi1958@mail.it,Via Passione,15,84125
CSTTVS96T03L010Q,Trevis,Casati,Lecce(LE),1996-12-03,treviscasati1996@mail.it,Via Paullo,36,84127
MRAMLL88L60A861W,Mirella,Amore,Brescia(BS),1988-07-20,mirellaamore1988@mail.it,Viale Monza,18,84129
CSTPCL65L28C370A,Pericle,Costantini,Verona(VR),1965-07-28,periclecostantini1965@mail.it,Piazza Tricolore,2,84122
CNSDLN69L12D258M,Dylan,Console,Sondrio(SO),1969-07-12,dylanconsole1969@mail.it,Via Fiori Oscuri,3,84124
PGNFST61E65G385N,Fausta,Paganelli,Milano (MI),1961-05-25,faustapaganelli1961@mail.it,Viale Piceno,12,84126
GCMNCY89A65F175U,Nancy,Giacometti,Pavia(PV),1989-01-25,nancygiacometti1989@mail.it,Viale Aretusa,102,84128
MCRJPH98P43H580P,Josephine,Macri,Vicenza(VI),1998-09-03,josephinemacri1998@mail.it,Via Comelico,73,84131
NNNJNN59T05C739F,Johnny,Annunziata,Asti(AT),1959-12-05,johnnyannunziata1959@mail.it,Via Maroncelli,45,84121
NPLSNT01T10I143D,Santo,Napoli,Salerno(SA),1995-12-10,santonapoli1995@mail.it,Via Gasparotto,33,84123
CNFDLA81M42I923T,Dalia,Conforti,Lecce(LE),1981-08-02,daliaconforti1981@mail.it,Via Navarra,150,84122
MNZRZO89L22D358Z,Orazio,Manzi,Cremona(CR),1989-07-22,oraziomanzi1989@mail.it,Via Ciaia,53,84123
BRNVRT90E66E372D,Venerita,Brunelli,Chieti(CH),1990-05-26,veneritabrunelli1990@mail.it,Via Lepontina,4,84121
CNINLC89C69G004C,Angelica,Cini,Cremona(CR),1989-03-29,angelicacini1989@mail.it,Via Degli Etruschi,89,84124
CLTGLM52H21C880M,Girolamo,Coletta,Rieti(RI),1952-06-21,girolamocoletta1952@mail.it,Via De Martino,179,84128