package progetto;
	
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ProgettoTester {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws SQLException {
		Connection connection = null;
		String databaseName= "progetto";
		String url= "jdbc:mysql://localhost:3306/" + databaseName;
		int avvio=1;
		
		//id utente
		String usernameDatabase= "ospite";
		String passwordDatabase= "ospite";
		
		//connessione
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection= DriverManager.getConnection(url, usernameDatabase, passwordDatabase);
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Collegamento fallito");
		}
		
		//variabili utili
		Scanner scanner= new Scanner(System.in);
		String username, clienteCf, dipendenteCf, codiceFiscale, nome, data, luogo;
		String  numRate, seriale, tipo, modello, autore;
		String telefono, appoggio, appoggio2, sql_query, nomeCorriere, premio;
		ArrayList<String> partecipantiCf=new ArrayList<String>();
		ArrayList<String> acquisti=new ArrayList<String>();
		int punti, punti_premio, n=0, k;
		double prezzo=1000;
		ResultSet ricercaDipendente=null;
		
		//men�
		while(avvio==1) {
			Statement statement= connection.createStatement();
			System.out.println("\nINSERIRE IL NUMERO DELL'OPERAZIONE CHE SI DESIDERA ESEGUIRE (0 per uscire)\nOP1-Inserimento di un cliente\nOP2-Inserimento di una vendita\nOP3-Inserimento di un account\nOP4-Inserimento/aggiornamento di un abbonamento");
			System.out.println("OP5-Inserimento di una dimostrazione\nOP6-Organizzazione di una spedizione\nOP7-Inserimento di una ricetta\nOP8-Inserimento di un voto");
			System.out.println("OP9-Inserimento di un premio\nOP10-Inserimento di un dipendente\nOP11-Inserimento di un robot\nOP12-Inserimento di una scelta");
			System.out.println("OP13-Selezionare nome, cognome ed e-mail di tutti i partecipanti che non sono diventati clienti");
			System.out.println("OP14-Selezionare nome e cognome di tutti i rappresentanti che non hanno concluso vendite negli ultimi tre mesi");
			System.out.println("OP15-Stampa di un elenco contenente nome, cognome e indirizzo dei clienti che hanno scelto premi ed il nome dei relativi premi scelti");
			System.out.println("OP16-Rimozione di tutte le ricette gourmet che hanno Stelle pari a 1 oppure 2 votate da almeno dieci persone");
			System.out.println("OP17-Elenco delle ricette base votate da almeno dieci persone che hanno un numero di stelle maggiore di 4");
			System.out.println("OP18-Stampa di una tabella contenente nome e cognome dei vari rappresentanti e il numero di robot venduti");
			System.out.println("OP19-Elenco di nome, cognome e indirizzo di tutti i clienti che hanno richiesto una vendita negli ultimi cinque giorni");
			System.out.println("OP20-Lista di nomi e cognomi dei partecipanti che hanno comprato un modello di robot in particolare");
			System.out.println("OP21-Elenco di nome, cognome e codice fiscale di tutti i clienti che hanno acquistato due robot con pagamento rateale");
			System.out.println("OP22-Elenco di tutti gli indirizzi dei clienti a cui sono stati consegnati robot durante una specifica spedizione");
			System.out.println("OP23-Numero di punti di un account");
			System.out.println("OP24-Nome e cognome dei rappresentanti che hanno venduto un robot a tutti i partecipanti di una dimostrazione");
			System.out.println("OP25-Nome e cognome degli impiegati che hanno predisposto una spedizione negli ultimi due mesi");
			System.out.println("OP26-Rimozione di un premio");
			System.out.println("OP27-Rimozione di una ricetta");
			System.out.println("OP28-Rimozione di un dipendente");
			System.out.print("\n>>>>> ");
			
			switch(scanner.nextInt()) {
			
				case 1:
					scanner.nextLine();
					System.out.println("\nINSERIMENTO DI UN CLIENTE");
					System.out.print("Codice fiscale: ");
					codiceFiscale=scanner.nextLine().toUpperCase();
					try {
						sql_query="INSERT INTO CLIENTE(`CF`, `Nome`, `Cognome`, `Luogo_nascita`, `Data_nascita`, `Email`, `Via`, `Civico`, `CAP`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?);";
						PreparedStatement prepared= connection.prepareStatement(sql_query);
						prepared.setString(1, codiceFiscale);
						System.out.print("Nome: ");
						prepared.setString(2, scanner.nextLine());
						System.out.print("Cognome: ");
						prepared.setString(3, scanner.nextLine());
						System.out.print("Luogo di nascita: ");
						prepared.setString(4, scanner.nextLine());
						System.out.print("Data di nascita: ");
						prepared.setString(5, scanner.nextLine());
						System.out.print("E-mail: ");
						prepared.setString(6, scanner.nextLine());
						System.out.print("Via: ");
						prepared.setString(7, scanner.nextLine());
						System.out.print("Civico: ");
						prepared.setString(8, scanner.nextLine());
						System.out.print("CAP: ");
						prepared.setString(9, scanner.nextLine());
						prepared.executeUpdate();
						k=1;
						do{
							if(k<=0)
								System.out.print("\nDevi avere almeno un numero di telefono!!\nRIPROVARE-> ");
							System.out.print("Quanti numeri di telefono si desidera inserire? (almeno 1): ");
							k=scanner.nextInt();
							scanner.nextLine();
						}while(k<=0);
						
						for(int i=0; i<k; i++) {
							System.out.print("\nNumero di telefono: ");
							telefono=scanner.nextLine();
							try {
								prepared= connection.prepareStatement("INSERT INTO TELEFONO_C VALUES('"+telefono+"', '"+codiceFiscale+"');");
								prepared.executeUpdate();
							} catch (SQLException e) {
								System.out.println("\nNumero di telefono non inserito!\nRIPROVARE-> ");
								i--;
							}
						}
						System.out.println("\nCliente Inserito!");
					} catch (SQLException e) {
						System.out.println("\nCliente non inserito!");
					}
					
					
				
                 break;
			case 2: 
					System.out.print("\nINSERIMENTO DI UNA VENDITA\nLa vendita � rateale?(SI o NO): ");
                    scanner.nextLine();
                    appoggio=scanner.nextLine();
                    System.out.print("Codice fiscale dipendente: ");
                    dipendenteCf= (scanner.nextLine()).toUpperCase();
                    try {
                        ResultSet r=statement.executeQuery("SELECT Tipo FROM DIPENDENTE WHERE CF ='"+dipendenteCf+"';");
                        r.next();
                        if(!r.getString(1).equals("RAPPRESENTANTE")) {
                        	System.out.println("\nDipendente non valido!");
                        	break;
                        }
                    }catch(SQLException e) {
                    	System.out.println("\nErrore!");
                    }
                    //
                    System.out.print("Codice fiscale cliente: ");
                    clienteCf=(scanner.nextLine()).toUpperCase();
                    System.out.print("Modello robot(TM5 o TM6): ");
                    modello=(scanner.nextLine()).toUpperCase();
                    try {
                        ResultSet r1=statement.executeQuery("SELECT DISTINCT R.Seriale FROM ROBOT_1 AS R WHERE R.Seriale NOT IN( SELECT Seriale FROM VENDITA) AND R.Modello='"+modello+"';");
                        r1.next();
                        seriale=r1.getString(1);
                    }catch(SQLException e) {
                    	System.out.println("\nNessun "+modello+" disponibile!");
                    	break;
                    }
                    try {
                        ResultSet r1=statement.executeQuery("SELECT Prezzo FROM ROBOT_2 AS R WHERE R.Modello='"+modello+"';");
                        r1.next();
                        prezzo=r1.getDouble(1);                     
                    }catch(SQLException e) {
                    	System.out.println("\nErrore!");
                    	break;
                    }
                    if (appoggio.equals("SI")) {
                        try {
                        	PreparedStatement prepared= connection.prepareStatement("INSERT INTO VENDITA VALUES(?, ?, CURDATE(), ?, ?, ?, ?);");
                        	prepared.setString(1, clienteCf);
                        	prepared.setString(2, dipendenteCf);
                        	System.out.print("Iban: ");
                        	prepared.setString(3, (scanner.nextLine()).toUpperCase());
                        	System.out.print("Numero rate: ");
                            numRate= scanner.nextLine();
                        	prepared.setDouble(4, prezzo/Integer.parseInt(numRate));
                        	prepared.setString(5, numRate);
                        	prepared.setString(6, seriale);
                        	prepared.executeUpdate();
                        	System.out.println("\nVendita inserita!");
                        }catch(SQLException e) {
                        	System.out.println("\nImpossibile inserire la vendita!");
                        	break;
                        }
                    }
                    else{
                    	try {
                        	PreparedStatement prepared= connection.prepareStatement("INSERT INTO VENDITA(CF_C, CF_D, Data_richiesta, Seriale) VALUES(?, ?, CURDATE(), ?);");
                        	prepared.setString(1, clienteCf);
                        	prepared.setString(2, dipendenteCf);
                        	prepared.setString(3, seriale);
                        	prepared.executeUpdate();
                        	System.out.println("\nVendita inserita!");
                        }catch(SQLException e) {
                        	System.out.println("\nImpossibile inserire la vendita!");
                        	break;
                        }
                    }
                    try {
                    	PreparedStatement prepared= connection.prepareStatement("UPDATE ACCOUNTT SET Punti=Punti+? WHERE ACCOUNTT.CF=?;");
                    	if(modello.equals("TM5"))
                    		prepared.setInt(1, 300);
                    	else
                    		prepared.setInt(1, 350);
                    	prepared.setString(2, clienteCf);
                    	prepared.executeUpdate();
                    	break;
                    }catch(SQLException e) {
                    	System.out.println("\nErrore!");
                    	break;
                    }
                        

				case 3:
					try {
	                    scanner.nextLine();
	                    System.out.println("\nINSERIMENTO DI UN ACCOUNT");
	                    System.out.print("Codice fiscale cliente: ");
	                    appoggio=(scanner.nextLine()).toUpperCase();
	                    
	                    
	                    String controllo= "SELECT Modello FROM VENDITA, ROBOT_1 WHERE VENDITA.CF_C='"+appoggio+"' AND ROBOT_1.Seriale=VENDITA.Seriale;";
	                    ResultSet sql_controllo= statement.executeQuery(controllo);
	                    int punti_ac=0;
	                   
	                    while(avvio==1){
	                        try {
	                            sql_controllo.next();
	                            if((sql_controllo.getString(1)).equals("TM5"))
	                                punti_ac+=300;
	                            else punti_ac+=350;
	                        } catch (SQLException errore) {
	                            break;
	                        }       
	                    }
	                    sql_query="INSERT INTO ACCOUNTT VALUES(?,?,?,?); ";
	                    PreparedStatement prepared=connection.prepareStatement(sql_query);
	                    System.out.print("Username: ");
	                    prepared.setString(1, username=scanner.nextLine());
	                    System.out.print("Password: ");
	                    prepared.setString(2, scanner.nextLine());                     
	                    prepared.setInt(3, punti_ac);
	                    prepared.setString(4, appoggio);
	                    prepared.executeUpdate();
	                    try {
	                        String relazione="INSERT INTO dispone_di SELECT ?, BASE.Nome, BASE.Autore FROM BASE;";
	                        PreparedStatement prepared_3= connection.prepareStatement(relazione);
	                        prepared_3.setString(1, username);
	                        prepared_3.executeUpdate();
	                        }
	                        catch(SQLException q) {
	                            System.out.println("\nErrore!");
	                        }
	                    System.out.println("\nAccount inserito!");
	                } catch (SQLException e) {
	                    System.out.println("\nPOSSIBILI ERRORI\n1-Il cliente possiede gi� un account\n2-Username gi� esistente\n");
	                }
	                break;
                
				case 4://OK
					System.out.println("\nINSERIMENTO/AGGIORNAMENTO DI UN ABBONAMENTO");
                    scanner.nextLine();
                    System.out.print("Username account: ");
                    appoggio=scanner.nextLine();
                    System.out.print(appoggio);
                       
                    try {//CONTROLLO SE L'ACCOUNT HA GIA' AVUTO UN ABBONAMENTO IN PASSATO
                    	sql_query="INSERT INTO ABBONATO VALUES(?, DATE_ADD(CURDATE(),INTERVAL 31 DAY))";
                        PreparedStatement prepared = connection.prepareStatement(sql_query);
                        prepared.setString(1, appoggio);
                        prepared.executeUpdate();
                        System.out.println("\nAbbonamento inserito!");
                        try {
                        String relazione="INSERT INTO possiede(Username, Ricetta_nome, Ricetta_autore) SELECT ?, RICETTA.Nome, RICETTA.Autore FROM RICETTA;";
                        PreparedStatement prepared_3= connection.prepareStatement(relazione);
                        prepared_3.setString(1, appoggio);
                        prepared_3.executeUpdate();
                        }
                        catch(SQLException q) {
                            System.out.println("\nErrore!");
                        }
                    } catch (SQLException e) {
                    	
                    	try{
	                    	sql_query="UPDATE ABBONATO SET Data_fine=DATE_ADD(Data_fine,INTERVAL 31 DAY) WHERE Username=?;";
	                        PreparedStatement prepared= connection.prepareStatement(sql_query);
	                        prepared.setString(1, appoggio);
	                        prepared.executeUpdate();
	                        System.out.println("\nAbbonamento aggiornato!");     
                        }
                        catch (SQLException p) {
                            System.out.println("\nImpossibile inserire aggiornamento!");
                        }
                    }
                    break;
					
				case 5:
					//INSERIMENTO DIPENDENTE.CF
					System.out.println("\nINSERIMENTO DI UNA DIMOSTRAZIONE");
					boolean flag=true, v=true;	//flag � false se il viene lanciata una SQLException e bisogna uscire dal case 
												//v � true se il partecipante inserito � gi� presente nel database
					scanner.nextLine();
					System.out.print("Codice fiscale dipendente: ");
					dipendenteCf=(scanner.nextLine()).toUpperCase();
					
						
					try {//CONTROLLO SE IL DIPENDENTE E' UN Rappresentante IN CASO AFFERMATIVO INSERISCO LA DIMOSTRAZIONE
						String controllo="SELECT Tipo FROM DIPENDENTE WHERE CF ='"+dipendenteCf+"';";
						ResultSet r=statement.executeQuery(controllo);
						r.next();
						if(!(r.getString(1)).equals("RAPPRESENTANTE")) {
							System.out.println("\nDipendente non valido!");
							break;
						}
						
					} catch (SQLException e) {
						System.out.println("\nErrore!");
						break;
					}
					
					System.out.print("Username dell'account: ");
					username=scanner.nextLine();
					System.out.print("Data: ");
					data=scanner.nextLine();
					System.out.print("Luogo: ");
					luogo=scanner.nextLine();
					
					//Inserisco il numero di partecipanti della dimostrazione
					n=2;
					do{
						if(n<2)
							System.out.print("\nI partecipanti devono essere almeno 2!\nRIPROVARE-> ");
						System.out.print("Quanti partecipanti si desidera inserire? (almeno 2): ");
						n=scanner.nextInt();
						scanner.nextLine();
					}while(n<2);
					
					punti=50;
					
					//INSERIMENTO PARTECIPANTI
					for(int i=0; i<n; i++) {
						boolean v1=true;//true indica che il partecipante i-esimo � valido
						System.out.println("\nInserimento partecipante "+(i+1)+": ");
						System.out.print("Codice fiscale partecipante: ");
						partecipantiCf.add(scanner.nextLine().toUpperCase());
						try {
							ResultSet r=statement.executeQuery("SELECT CF FROM ACCOUNTT WHERE Username='"+username+"';");
							if(r.next()==true && partecipantiCf.get(i).equals(r.getString(1))) {
								System.out.print("Partecipante non valido!\n\nRIPROVARE-> ");
								partecipantiCf.remove(i);
								v1=false;
								i--;
							}
						}catch (SQLException e) {
							System.out.println("\nErrore!");
							flag=false;
							break;
						}
						
						if(v1) 
							try{//CONTROLLA SE IL PARTECIPANTE ESISTE GIA' E SE PUO' PARTECIPARE ALLA DIMOSTRAZIONE
								String controllo="SELECT '"+partecipantiCf.get(i)+"' IN(SELECT CF FROM PARTECIPANTE);";
								ResultSet r=statement.executeQuery(controllo);
								r.next();
								v=r.getBoolean(1);
							}catch (SQLException e) {
								System.out.println("\nErrore!");
								flag=false;
								break;
							}
						if(v && v1) {
							System.out.println("\nPartecipante esistente!");
							
							try {//controlla se ha gi� partecipato alla dimostrazione del cliente 
								String controllo2="SELECT '"+partecipantiCf.get(i)+"' IN(SELECT CF_P FROM partecipa AS p WHERE p.Username='"+username+"');";
								ResultSet r1=statement.executeQuery(controllo2);
								r1.next();
								if(r1.getBoolean(1)) {
									System.out.print("Partecipante non valido!\n\nRIPROVARE-> ");
									partecipantiCf.remove(i);
									v1=false;
									i--;
								}
							} catch (SQLException e) {
								flag=false;
								System.out.println("\nErrore!");
								break;
							}
						}
						else if(v1){
							
							try {
								sql_query="INSERT INTO PARTECIPANTE VALUES(?, ?, ?, ?)";
								PreparedStatement prepared = connection.prepareStatement(sql_query);
								prepared.setString(1, partecipantiCf.get(i));
								System.out.print("Nome: ");
								prepared.setString(2, scanner.nextLine());
								System.out.print("Cognome: ");
								prepared.setString(3, scanner.nextLine());
								System.out.print("Email: ");
								prepared.setString(4, scanner.nextLine());
								prepared.executeUpdate();
								System.out.println("\nPartecipante inserito!");
							}catch (SQLException e) {
								System.out.println("\nErrore inserimento partecipante!");
								flag=false;
								break;
							}
						}
						if(v1) {
							System.out.print("Il partecipante "+(i+1)+" ha effettuato l'acquisto? (SI/NO): ");
							if((scanner.nextLine().toUpperCase()).equals("SI")) {
								acquisti.add(i, "1");;
								punti=100;
							}
							else
								acquisti.add(i, "0");
						}
					}
					
					if(flag) {
						try {//INSERIMENTO DIMOSTRAZIONE
							sql_query="INSERT INTO DIMOSTRAZIONE VALUES(?, ?, ?, ?)";
							PreparedStatement prepared = connection.prepareStatement(sql_query);
							prepared.setString(1, dipendenteCf);
							prepared.setString(2, username);
							prepared.setString(3, data);
							prepared.setString(4, luogo);
							prepared.executeUpdate();
						} catch(SQLException e){
							System.out.println("\nImpossibile inserire la dimostrazione!");
							for(int i=n-1; i>=0;i--) {
								try {
									sql_query="DELETE FROM PARTECIPANTE WHERE CF=?";
									PreparedStatement prepared = connection.prepareStatement(sql_query);
									prepared.setString(1, partecipantiCf.get(i));
								}catch (SQLException e1) {
									System.out.println("\nPartecipante "+partecipantiCf.get(i)+" non rimosso");
								}
							}
							break;
						}
					}
					
					for(int i=0; i<n; i++) {
						try {
							PreparedStatement prepared = connection.prepareStatement("INSERT INTO partecipa VALUES(?, ?, ?, ?, ?);");
							prepared.setString(1, dipendenteCf);
							prepared.setString(2, username);
							prepared.setString(3, data);
							prepared.setString(4, partecipantiCf.get(i));
							prepared.setString(5, acquisti.get(i));	
							prepared.executeUpdate();
							
						} catch (SQLException e) {
							System.out.println("\nErrore inserimento partecipazione!");
							break;
						}							
					}
					
					if(flag) {
						try {//AGGIORNAMENTO DEI PUNTI
							PreparedStatement prepared = connection.prepareStatement("UPDATE ACCOUNTT SET Punti=Punti+? WHERE Username=?;");
							prepared.setInt(1, punti);
							prepared.setString(2, username);
							prepared.executeUpdate();
							System.out.println("\nDimostrazione inserita!");
						} catch(SQLException e){
							System.out.println("\nImpossibile aggiornare i punti dell'account!");
							break;
						}	
					}
					
					break;
			
				case 6:
					
					System.out.println("\nORGANIZZAZIONE DI UNA SPEDIZIONE"); 
                    scanner.nextLine();
                    
                    try {
                    	ResultSet r=statement.executeQuery("SELECT COUNT(*) FROM ROBOT_1 AS R, VENDITA AS V WHERE R.Seriale=V.Seriale AND R.`#spedizione` IS NULL;");
                    	r.next();
                    	if(r.getInt(1)==0) {
                    		System.out.println("\nNon ci sono robot da spedire!");
                       	 	break;
                    	}
                    } catch (SQLException e) {
                   	 	System.out.println("\nErrore!");
                   	 	break;
                    }
                    System.out.print("Codice fiscale impiegato: ");
                    codiceFiscale=(scanner.nextLine()).toUpperCase();
                    try {  //controllo esistenza dipendente
                        ricercaDipendente=statement.executeQuery("SELECT Tipo FROM DIPENDENTE WHERE CF ='"+codiceFiscale+"';");
                        ricercaDipendente.next();
                        appoggio=ricercaDipendente.getString(1);
                    } catch (SQLException e) {
                    	 System.out.println("\nErrore dipendente!");
                         break;
                    }
                        
                    if(appoggio.equals("IMPIEGATO")) { 
                    	System.out.print("Nome corriere: ");
                        nomeCorriere= scanner.nextLine();
                        ResultSet r1=statement.executeQuery("SELECT '"+nomeCorriere+"' IN(SELECT Corr FROM SPEDIZIONE_2);");
                        r1.next();
                        
                        if (!r1.getBoolean(1)) {
                        	System.out.print("Telefono corriere: ");
                            telefono=scanner.nextLine();
                            try{
                            	PreparedStatement prepared= connection.prepareStatement("INSERT INTO SPEDIZIONE_2 VALUES('"+nomeCorriere+"', '"+telefono+"');");
                            	prepared.executeUpdate();
                            } catch (SQLException e) {
                            	System.out.println("\nImpossibile inserire corriere!");
                            }
                        }
                        
                        try{
                        	PreparedStatement prepared= connection.prepareStatement("INSERT INTO SPEDIZIONE_1(`Corr`, `Data`, `CF`) VALUES('"+nomeCorriere+"', CURDATE(), '"+codiceFiscale+"');");
                            prepared.executeUpdate();
                        } catch (SQLException e) {
                        	System.out.println("\nImpossibile inserire spedizione!");
                        }
                        
                        try{
                        	ResultSet r3=statement.executeQuery("SELECT MAX(`#spedizione`) FROM SPEDIZIONE_1;");
                            r3.next();
                            PreparedStatement prepared= connection.prepareStatement("UPDATE ROBOT_1 SET `#spedizione`=? WHERE ROBOT_1.`#spedizione` IS NULL AND ROBOT_1.Seriale IN(SELECT Seriale FROM VENDITA);");
                            prepared.setInt(1, r3.getInt(1));
                            prepared.executeUpdate();
                            System.out.println("\nSpedizione inserita!");
                        } catch (SQLException e) {
                        	System.out.println("\nErrore!");
                        }
                    }
                    else
                    	System.out.println("Dipendente non valido");
                        
                    break;
					
				case 7:
					
					System.out.println("\nINSERIMENTO DI UNA RICETTA");
					scanner.nextLine();
					try {
						sql_query="INSERT INTO RICETTA VALUES(?, ?, ?, ?);";
						PreparedStatement prepared= connection.prepareStatement(sql_query);
						System.out.print("Nome ricetta: ");
						prepared.setString(1,nome=scanner.nextLine());
						System.out.print("Autore ricetta: ");
						prepared.setString(2,autore=scanner.nextLine());
						System.out.print("Difficolt� (1 \"BASSA\" - 10 \"ALTA\"): ");
						prepared.setInt(3,scanner.nextInt());
						scanner.nextLine();
						System.out.print("Descrizione: ");
						prepared.setString(4,scanner.nextLine());
						prepared.executeUpdate();
						
						System.out.print("La ricetta � base o gourmet?(BASE o GOURMET): ");
						tipo=(scanner.nextLine()).toUpperCase();
						try {
							sql_query="INSERT INTO "+tipo+" VALUES(?, ?);";
							PreparedStatement prepared1= connection.prepareStatement(sql_query);
							prepared1.setString(1,nome);
							prepared1.setString(2,autore);
							prepared1.executeUpdate();
						} catch (SQLException e) {
							System.out.println("\nLa ricetta non pu� essere "+tipo);
							break;
						}
						//INSERIMENTO DELLE RELAZIONI//////////////////////////////////////////////
						if (tipo.equals("BASE")) {
							sql_query="INSERT INTO dispone_di SELECT Username , ? , ? from ACCOUNTT;"; 
							try{
								PreparedStatement prepared1= connection.prepareStatement(sql_query);
								prepared1.setString(1,nome);
								prepared1.setString(2,autore);
								prepared1.executeUpdate();
							} catch (SQLException e) {
								System.out.println("\nERRORE");
							}
						}
						try{
							sql_query="INSERT INTO possiede(Username, Ricetta_nome, Ricetta_autore) SELECT Username , ? , ? FROM ABBONATO;";
							PreparedStatement prepared1= connection.prepareStatement(sql_query);
							prepared1.setString(1,nome);
							prepared1.setString(2,autore);
							prepared1.executeUpdate();
						} catch (SQLException e) {
							System.out.println("\nERRORE");
						}
						///////////////////////////////////////////////////////////////////////////
						System.out.println("\nRicetta inserita!");
					} catch (SQLException e) {
						System.out.println("\nImpossibile inserire la ricetta");
					}
					
					break;
					
				case 8:
					scanner.nextLine();
					System.out.println("\nINSERIMENTO DI UN VOTO");
	                	try {
	                        sql_query="UPDATE possiede SET Voto=? WHERE possiede.Username=? AND Ricetta_autore=? AND Ricetta_nome=? AND Voto IS NULL AND ? IN( SELECT Username FROM ABBONATO WHERE DATEDIFF(Data_fine,CURDATE())>0) ;";
	                        PreparedStatement prepared = connection.prepareStatement(sql_query);
	                        System.out.print("Username account: ");
	                        prepared.setString(2, appoggio=scanner.nextLine());
	                        try {
	                        	ResultSet r=statement.executeQuery("SELECT '"+appoggio+"' IN(SELECT Username FROM ABBONATO);");
	                        	r.next();
	                        	if(!r.getBoolean(1)) {
	                        		System.out.println("\nAbbonamento inesistente\nQuesto utente non pu� votare!");
	                        		break;
	                        	}
	                        }catch(SQLException i) {
		                        System.out.println("\nErrore!");
		                        break;
		                    }
	                        try {
	                        	ResultSet r=statement.executeQuery("SELECT DATEDIFF(CURDATE(), Data_fine)  FROM ABBONATO WHERE ABBONATO.Username='"+appoggio+"';");
	                        	r.next();
	                        	if(r.getInt(1)>0) {
	                        		System.out.println("\nAbbonamento scaduto\nQuesto utente non pu� votare!");
	                        		break;
	                        	}
	                        }catch(SQLException i) {
		                        System.out.println("\nErrore!");
		                        break;
		                    }
	                        System.out.print("Nome autore: ");
	                        prepared.setString(3, autore=(scanner.nextLine()).toUpperCase());
	                        System.out.print("Nome ricetta: ");
	                        prepared.setString(4, nome=(scanner.nextLine()).toUpperCase());
	                        try {
	                        	ResultSet r=statement.executeQuery("SELECT Voto IS NULL FROM possiede AS p WHERE p.Username='"+appoggio+"' AND p.Ricetta_nome='"+nome+"' AND p.Ricetta_autore='"+autore+"';");
	                        	r.next();
	                        	if(!r.getBoolean(1)) {
	                        		System.out.println("\nQuesto utente ha gi� votato questa ricetta!");
	                        		break;
	                        	}
	                        }catch(SQLException i) {
		                        System.out.println("\nErrore!");
		                        break;
		                    }
	                        prepared.setString(5, appoggio);
	                        System.out.print("Voto: ");
	                        prepared.setInt(1, scanner.nextInt());
	                        scanner.nextLine();
	                        prepared.executeUpdate(); 
	                        System.out.println("\nVoto inserito!");
	                    }catch(SQLException i) {
	                        System.out.println("\nNon � stato possibile inserire il voto!");
	                    }
	                    break;
					
				case 9:
					System.out.println("\nINSERIMENTO DI UN PREMIO");
					scanner.nextLine();
					try {
                        sql_query="INSERT INTO PREMIO VALUES(?,?,?)";
                        PreparedStatement prepared=connection.prepareStatement(sql_query);
                        System.out.print("Nome premio: ");
                        prepared.setString(1, scanner.nextLine());
                        System.out.print("Punti: ");
                        prepared.setInt(2, scanner.nextInt());
                        System.out.print("Numero unit�: ");
                        prepared.setInt(3, scanner.nextInt()); 
                        prepared.executeUpdate();
                        System.out.println("\nPremio inserito!");
                    } catch (SQLException e) {
                        System.out.println("\nPremio non inserito!");
                    }
                    break;
					
				case 10: 
					scanner.nextLine();
                    System.out.println("\nINSERIMENTO DI UN DIPENDENTE");
                    System.out.print("Codice fiscale: ");
                    codiceFiscale=scanner.nextLine();
                    try {
                        sql_query="INSERT INTO DIPENDENTE VALUES(?,?,?,CURDATE(),?); ";
                        PreparedStatement prepared= connection.prepareStatement(sql_query);
                       
                        prepared.setString(1, codiceFiscale);
                        System.out.print("Nome: ");
                        prepared.setString(2, scanner.nextLine());
                        System.out.print("Cognome: ");
                        prepared.setString(3, scanner.nextLine());
                        System.out.print("Che tipo di dipendente �?(Rappresentante o Impiegato): ");
                        prepared.setString(4, (scanner.nextLine()).toUpperCase());
                        prepared.executeUpdate(); 
                        k=1;
    					do{
    						if(k<=0)
    							System.out.print("\nDevi avere almeno un numero di telefono!!\nRIPROVARE-> ");
    						System.out.print("Quanti numeri di telefono si desidera inserire? (almeno 1): ");
    						k=scanner.nextInt();
    						scanner.nextLine();
    					}while(k<=0);
    					
    					for(int i=0; i<k; i++) {
    						System.out.print("\nNumero di telefono: ");
    						telefono=scanner.nextLine();
    						try {
    							prepared= connection.prepareStatement("INSERT INTO TELEFONO_D VALUES('"+telefono+"', '"+codiceFiscale+"');");
    							prepared.executeUpdate();
    						} catch (SQLException e) {
    							System.out.println("\nNumero di telefono non inserito!\nRIPROVARE-> ");
    							i--;
    						}
    					}
                       
                        System.out.println("\nDipendente inserito!");
                       
                    } catch (SQLException e) {
                        System.out.println("\nNon � possibile inserire il dipendente!");
                    }
                   
					
                    break;
					
				case 11: 
					scanner.nextLine();
                    System.out.println("\nINSERIMENTO DI UN ROBOT");
                    try {
                    	sql_query="INSERT INTO ROBOT_1(`Seriale`, `Modello`) VALUES (?,?); ";
                        PreparedStatement prepared=connection.prepareStatement(sql_query);
                       
                        System.out.print("Seriale: ");
                        prepared.setString(1, (scanner.nextLine()).toUpperCase());
                        System.out.print("Modello(TM5 o TM6): ");
                        prepared.setString(2, scanner.nextLine().toUpperCase());
                        prepared.executeUpdate();
                        System.out.println("\nRobot inserito!");      
                       
                    } catch (SQLException e) {
                        System.out.println("\nRobot non inserito!");
                    }
                    break;
                    
				case 12: 
					scanner.nextLine();
					System.out.println("\nINSERIMENTO DI UNA SCELTA");
		
                    try {
                    	sql_query="INSERT INTO sceglie VALUES (?,?); ";
                        PreparedStatement prepared=connection.prepareStatement(sql_query);
                        System.out.println("Username: ");
                        prepared.setString(1, username=scanner.nextLine());
                        System.out.print("Nome premio: ");
                        prepared.setString(2, premio=scanner.nextLine().toUpperCase());
                        //Prendo i punti dell'account
                        try {
                        	ResultSet r=statement.executeQuery("SELECT Punti FROM ACCOUNTT WHERE Username ='"+username+"';");
                        	r.next();
                        	punti=r.getInt(1);
                        } catch (SQLException e) {
                            System.out.println("\nImpossibile reperire punti dell'account!");
                            break;
                        }
                        //prendo i punti e il numero di unit� del premio
                        try {
                        	ResultSet r=statement.executeQuery("SELECT Punti, `#unit�` FROM PREMIO WHERE Nome ='"+premio+"';");
                        	r.next();
                        	if(r.getInt(2)==0) {
                        		System.out.println("\nIl premio non � disponibile!");
                        		break;
                        	}	
                        	punti_premio=r.getInt(1);	
                        } catch (SQLException e) {
                            System.out.println("\nErrore!");
                            break;
                        }
                        
                        if(punti>=punti_premio) {
                        	prepared.executeUpdate();
                            System.out.println("\nScelta inserita!"); 
                            //aggiorno i punti dell'account
                            prepared=connection.prepareStatement("UPDATE ACCOUNTT SET Punti=Punti-? WHERE Username=?;");
                            prepared.setInt(1, punti_premio);
                            prepared.setString(2, username);
                            prepared.executeUpdate();
                            //aggiorno #unit� di premio
                            prepared=connection.prepareStatement("UPDATE PREMIO SET `#unit�`=`#unit�`-1 WHERE Nome=?;");
                            prepared.setString(1, premio);
                            prepared.executeUpdate();
                        }
                        else
                        	System.out.println("\nI punti dell'account non sono sufficienti!");

                    } catch (SQLException e) {
                        System.out.println("\nScelta non inserita!");
                    }
                    break;
                    
				case 13:
					scanner.nextLine();
					System.out.println("SELEZIONARE NOME, COGNOME ED E-MAIL DI TUTTI I PARTECIPANTI CHE NON SONO DIVENTATI CLIENTI\n");
					try {
                    	ResultSet r=statement.executeQuery("SELECT DISTINCT Nome, Cognome, Email FROM PARTECIPANTE AS P WHERE P.CF NOT IN (SELECT CF_P FROM partecipa AS pa WHERE pa.Acquisto='1');");
                    	
                    	System.out.format("%-15s%-15s%-30s\n\n",  "NOME", "COGNOME", "E-MAIL");
                    	
                    	while(r.next()==true) {
                    	    System.out.format("%-15s%-15s%-30s\n", r.getString(1), r.getString(2), r.getString(3));
                    	}
                    	
					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					break;
                    	
				case 14:
					scanner.nextLine();
					System.out.println("SELEZIONARE NOME E COGNOME ED E-MAIL DI TUTTI I RAPPRESENTANTI CHE NON HANNO CONCLUSO VENDITE NEGLI ULTIMI TRE MESI\n");
					try {
                    	ResultSet r=statement.executeQuery("SELECT Nome, Cognome FROM DIPENDENTE AS D WHERE D.Tipo='RAPPRESENTANTE' AND D.CF NOT IN( SELECT CF_D FROM VENDITA AS V WHERE DATEDIFF(CURDATE(),V.Data_richiesta)<=90);");
                    	System.out.format("%-15s%-15s\n\n",  "NOME", "COGNOME");
                    	
                    	while(r.next()==true) {
                    	    System.out.format("%-15s%-15s\n", r.getString(1), r.getString(2));
                    	}

					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					break;
					
				case 15:
					scanner.nextLine();
					System.out.println("STAMPA DI UN ELENCO CONTENENTE NOME, COGNOME E INDIRIZZO DEI CLIENTI CHE HANNO SCELTO PREMI ED IL NOME DEI RELATIVI PREMI SCELTI\n");
					System.out.print("A questa operazione segue l�azzeramento dei punti di tutti gli account e l�eliminazione di tutte le scelte.\nProseguire? (SI/NO): ");
					if(((scanner.nextLine()).toUpperCase()).equals("NO"))
						break;
					try {
                    	ResultSet r=statement.executeQuery("SELECT C.Nome, C.Cognome, C.Via, C.Civico, C.CAP, s.Premio_nome AS Premio FROM CLIENTE AS C, ACCOUNTt AS A, sceglie AS s WHERE C.CF=A.CF AND A.Username=s.Username;");
                    	System.out.format("%-15s%-15s%-20s%-10s%-10s%-60s\n\n",  "NOME", "COGNOME", "VIA", "CIVICO", "CAP", "PREMIO");
                    	
                    	while(r.next()==true) {
                    	    System.out.format("%-15s%-15s%-20s%-10d%-10s%-60s\n", r.getString(1), r.getString(2), r.getString(3), r.getInt(4), r.getString(5), r.getString(6));
                    	}
                    	                    	
					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					
					try {
						PreparedStatement prepared=connection.prepareStatement("UPDATE ACCOUNTT SET Punti=0;");
                        prepared.executeUpdate();
                        prepared=connection.prepareStatement("DELETE FROM sceglie;");
                        prepared.executeUpdate();
					}catch(SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					
					break;
					
				case 16:
					
					scanner.nextLine();
					System.out.println("RIMOZIONE DI TUTTE LE RICETTE GOURMET CHE HANNO STELLE PARI A 1 OPPURE 2 VOTATE DA ALMENO DIECI PERSONE\n");

					try {
						statement.execute("DELETE FROM RICETTA WHERE (Nome, Autore) IN(SELECT DISTINCT G.Nome, G.Autore FROM GOURMET AS G, possiede AS p WHERE G.Nome=p.Ricetta_nome AND G.Autore=p.Ricetta_autore GROUP BY G.Nome, G.Autore HAVING AVG(p.Voto)<3 AND COUNT(p.Voto)>=10);");	
						System.out.println("\nRicette rimosse!");
					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					
					break;
					
				case 17:
					scanner.nextLine();
					System.out.println("ELENCO DELLE RICETTE BASE VOTATE DA ALMENO DIECI PERSONE CHE HANNO UN NUMERO DI STELLE MAGGIORE DI 4\n");
					
					try {
                    	ResultSet r=statement.executeQuery("SELECT DISTINCT B.Nome, B.Autore FROM BASE AS B, possiede AS p WHERE B.Nome=p.Ricetta_nome AND B.Autore=p.Ricetta_autore GROUP BY B.Nome, B.Autore HAVING AVG(p.Voto)>4 AND COUNT(p.Voto)>=10;");
                    	System.out.format("%-40s%-20s\n\n",  "NOME RICETTA", "AUTORE");
                    	
                    	while(r.next()==true) {
                    	    System.out.format("%-40s%-20s\n", r.getString(1), r.getString(2));
                    	}
                    	
                    	System.out.format("%-40s%-20s\n", "NULL", "NULL");
                    	
					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					
					break;
					
				case 18:
					scanner.nextLine();
					System.out.println("STAMPA DI UNA TABELLA CONTENENTE NOME E COGNOME DEI VARI RAPPRESENTANTI E IL NUMERO DI ROBOT VENDUTI\n");
					try {
	                	ResultSet r=statement.executeQuery("SELECT DISTINCT Nome, Cognome, COUNT(D.CF) FROM DIPENDENTE AS D, VENDITA AS V WHERE D.CF=V.CF_D AND D.Tipo='RAPPRESENTANTE' GROUP BY CF_D;");
	                	System.out.format("%-15s%-15s%-13s\n\n",  "NOME", "COGNOME", "ROBOT VENDUTI");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-15s%-15s%-13d\n", r.getString(1), r.getString(2), r.getInt(3));
	                	}

					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
					
				case 19:
					scanner.nextLine();
					System.out.println("ELENCO DI NOME, COGNOME E INDIRIZZO DI TUTTI I CLIENTI CHE HANNO RICHIESTO UNA VENDITA NEGLI ULTIMI 5 GIORNI\n");
					try {
                    	ResultSet r=statement.executeQuery("SELECT Nome, Cognome, Via, Civico, CAP FROM CLIENTE AS C, VENDITA AS V WHERE V.CF_C=C.CF AND DATEDIFF(CURDATE(),V.Data_richiesta)<=5;");
                    	System.out.format("%-15s%-15s%-20s%-10s%-10s\n\n",  "NOME", "COGNOME", "VIA", "CIVICO", "CAP");
                    	
                    	while(r.next()==true) {
                    	    System.out.format("%-15s%-15s%-20s%-10d%-10s\n", r.getString(1), r.getString(2), r.getString(3), r.getInt(4), r.getString(5));
                    	}
                    	
					} catch (SQLException e) {
                        System.out.println("\nImpossibile effettuare l'operazione!");
                    }
					break;
					
				case 20:
					
					scanner.nextLine();
					System.out.println("LISTA DI NOMI E COGNOMI DEI PARTECIPANTI CHE HANNO COMPRATO UN MODELLO DI ROBOT IN PARTICOLARE\n");
					System.out.println("Modello: ");
					try {
	                	ResultSet r=statement.executeQuery("SELECT P.Nome AS Nome, P.Cognome AS Cognome FROM PARTECIPANTE AS P, CLIENTE AS C, VENDITA AS V, ROBOT_1 AS R WHERE P.CF=C.CF AND V.CF_C=C.CF AND V.Seriale=R.Seriale AND R.Modello LIKE '"+(scanner.nextLine()).toUpperCase()+"';");
	                	System.out.format("%-15s%-15s\n\n",  "NOME", "COGNOME");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-15s%-15s\n", r.getString(1), r.getString(2));
	                	}
	                	
					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
					
				case 21:
					
					scanner.nextLine();
					System.out.println("ELENCO DI NOME, COGNOME E CODICE FISCALE DI TUTTI I CLIENTI CHE HANNO ACQUISTATO DUE ROBOT CON PAGAMENTO RATEALE\n");
					try {
	                	ResultSet r=statement.executeQuery("SELECT DISTINCT C.Nome, C.Cognome, C.CF FROM CLIENTE AS C, vendita AS v WHERE C.CF=v.CF_C AND v.IBAN IS NOT NULL GROUP BY C.Nome, C.Cognome, C.CF HAVING COUNT(*)>=2;");
	                	System.out.format("%-15s%-15s%-16s\n\n",  "NOME", "COGNOME", "CODICE FISCALE");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-15s%-15s%-16s\n", r.getString(1), r.getString(2), r.getString(3));
	                	}

					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
					
				case 22: 
					scanner.nextLine();
					System.out.println("ELENCO DI TUTTI GLI INDIRIZZI DEI CLIENTI A CUI SONO STATI CONSEGNATI ROBOT DURANTE UNA SPECIFICA SPEDIZIONE\n");
					System.out.print("Numero spedizione: ");
					try {
	                	ResultSet r=statement.executeQuery("SELECT C.Via, C.Civico, C.CAP FROM CLIENTE AS C, SPEDIZIONE_1 AS S, ROBOT_1 AS R, VENDITA AS V WHERE C.CF=V.CF_C AND V.Seriale=R.Seriale AND R.`#spedizione`=S.`#spedizione` AND S.`#spedizione` = "+scanner.nextLine()+";");
	                	System.out.format("%-20s%-10s%-10s\n\n", "VIA", "CIVICO", "CAP");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-20s%-10d%-10s\n", r.getString(1), r.getInt(2), r.getString(3));
	                	}

					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
					
				case 23:
					
					scanner.nextLine();
					System.out.println("NUMERO DI PUNTI DI UN ACCOUNT\n");
					System.out.print("Username: ");
					try {
	                	ResultSet r=statement.executeQuery("SELECT Punti FROM ACCOUNTT WHERE Username='"+scanner.nextLine()+"';");
	                	r.next();
	                	System.out.println("L'account possiede "+r.getInt(1)+" punti.");
					} catch (SQLException e) {
	                    System.out.println("\nAccount non trovato!");
	                }
					break;
				
				case 24:
					scanner.nextLine();
					System.out.println("NOME E COGNOME DEI RAPPRESENTANTI CHE HANNO VENDUTO UN ROBOT A TUTTI I PARTECIPANTI DI UNA DIMOSTRAZIONE\n");
					try {
	                	ResultSet r=statement.executeQuery("SELECT DISTINCT DI.Nome, DI.Cognome, DI.CF FROM DIPENDENTE AS DI WHERE DI.CF IN (SELECT DISTINCT DI.CF FROM DIPENDENTE "
	                			+"AS DI, DIMOSTRAZIONE AS D, partecipa AS p WHERE DI.CF=D.CF AND D.Username=p.Username AND D.`Data`=p.`Data` AND D.CF=p.CF_D "
	                			+"GROUP BY DI.CF, D.Username, D.`Data` HAVING COUNT(DISTINCT Acquisto)=1) AND DI.CF IN (SELECT DISTINCT D.CF FROM DIMOSTRAZIONE " 
	                			+"AS D, partecipa AS p WHERE D.Username=p.Username AND D.`Data`=p.`Data` AND D.CF=p.CF_D AND p.Acquisto='1');");
	                	
	                	System.out.format("%-15s%-15s\n\n",  "NOME", "COGNOME");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-15s%-15s\n", r.getString(1), r.getString(2));
	                	}

					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
					
				case 25:
					scanner.nextLine();
					System.out.println("NOME E COGNOME DEGLI IMPIEGATI CHE HANNO PREDISPOSTO UNA SPEDIZIONE NEGLI ULTIMI DUE MESI\n");
					try {
	                	ResultSet r=statement.executeQuery("SELECT D.Nome, D.Cognome FROM DIPENDENTE AS D, SPEDIZIONE_1 AS S WHERE D.CF=S.CF AND DATEDIFF(CURDATE(), S.`Data`)<=60;");
	                	
	                	System.out.format("%-15s%-15s\n\n",  "NOME", "COGNOME");
	                	
	                	while(r.next()==true) {
	                	    System.out.format("%-15s%-15s\n", r.getString(1), r.getString(2));
	                	}

					} catch (SQLException e) {
	                    System.out.println("\nImpossibile effettuare l'operazione!");
	                }
					break;
				
				case 26: 
					
					System.out.println("\nRIMOZIONE DI UN PREMIO");
					scanner.nextLine();
					try {
	                    PreparedStatement prepared=connection.prepareStatement("DELETE FROM PREMIO WHERE Nome=?;");
	                    System.out.print("Nome premio: ");
	                    prepared.setString(1,scanner.nextLine());
	                    prepared.executeUpdate();
	                    System.out.println("\nPremio rimosso!");
	                } catch (SQLException e) {
	                    System.out.println("\nErrore!");
	                }
                break;
				
				case 27: 
					
					System.out.println("\nRIMOZIONE DI UNA RICETTA");
					scanner.nextLine();
					try {
						PreparedStatement prepared=connection.prepareStatement("DELETE FROM RICETTA WHERE Nome=? AND Autore=?;");
	                    System.out.print("Nome ricetta: ");
	                    prepared.setString(1,(scanner.nextLine()).toUpperCase());
	                    System.out.print("Autore: ");
	                    prepared.setString(2,(scanner.nextLine()).toUpperCase());
	                    prepared.executeUpdate();
	                    System.out.println("\nRicetta rimossa!");
	                } catch (SQLException e) {
	                    System.out.println("\nErrore!");
	                }
                break;
				
				case 28: 
					
					System.out.println("\nRIMOZIONE DI UN DIPENDENTE");
					scanner.nextLine();
					try {
						PreparedStatement prepared=connection.prepareStatement("DELETE FROM DIPENDENTE WHERE CF=?");
	                    System.out.print("Codice fiscale del dipendente: ");
	                    prepared.setString(1,(scanner.nextLine()).toUpperCase());
	                    prepared.executeUpdate();
	                    System.out.println("\nDipendente rimosso!");
	                } catch (SQLException e) {
	                    System.out.println("\nErrore!");
	                }
                break;
       
				case 0:
					System.out.println("\nArrivederci!");
					scanner.close();
					connection.close();
					System.exit(1);
					break;
					
				default:
					System.out.println("\nInserimento non valido!");
					break;
				}
		}	
	}
}